const express = require('express')
const fs = require('fs')
const moviesData = require('./movies.json')

const app = express()
const PORT = 3000

// Middleware para parsear el body de las peticiones
app.use(express.json())

// Endpoint para obtener todas las películas
app.get('/movies', (req, res) => {
    res.json(moviesData)
})

// Endpoint para obtener información de una película por su ID
app.get('/movies/:id', (req, res) => {
    const id = req.params.id
    const movie = moviesData.find(movie => movie.id === id)
    if (!movie) {
        res.json(movie)
    } else {
        res.status(404).json({ error: 'Movie not found', message: 'No se encontró la película con el ID proporcionado' })
    }
})

// Endpoint para crear una nueva película
app.post('/movies', (req, res) => {
    const newMovie = req.body
    moviesData.push(newMovie)
    fs.writeFileSync('./movies.json', JSON.stringify(moviesData, null, 2))
    res.status(201).json(newMovie)
})

// Endpoint para modificar una película existente
app.put('/movies/:id', (req, res) => {
    const id = req.params.id
    const updatedMovie = req.body
    const index = moviesData.findIndex(movie => movie.id === id)
    if (index !== -1) {
        moviesData[index] = updatedMovie
        fs.writeFileSync('./movies.json', JSON.stringify(moviesData, null, 2))
        res.json(updatedMovie)
    } else {
        res.status(404).json({ error: 'Movie not found', message: 'No se encontró la película con el ID proporcionado' })
    }
})

// Endpoint para eliminar una película
app.delete('/movies/:id', (req, res) => {
    const id = req.params.id
    const index = moviesData.findIndex(movie => movie.id === id)
    if (index !== -1) {
        moviesData.splice(index, 1)
        fs.writeFileSync('./movies.json', JSON.stringify(moviesData, null, 2))
        res.json({ message: 'Película eliminada exitosamente' })
    } else {
        res.status(404).json({ error: 'Movie not found', message: 'No se encontró la película con el ID proporcionado' })
    }
})

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(` Serviedor ejecutandose en el puerto ${PORT}`)
})
